<?php
global $_DOCMAN;

?>

DOCMan v<?php echo $_DOCMAN->getCfg('docman_version');
?> - 2003 - 2005 The DOCMan Development Team - <a href="http://www.mambodocman.com/" target="_blank">www.mambodocman.com</a>