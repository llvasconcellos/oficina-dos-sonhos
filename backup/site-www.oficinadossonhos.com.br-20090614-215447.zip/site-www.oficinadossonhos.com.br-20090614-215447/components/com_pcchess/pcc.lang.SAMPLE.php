<?php
// Language file for princeclan chess component.
// This is a localized file and should be included AFTER pcc.lang.us.php.
// It assumes $pcc_lang has been defined and filled in already.
// This allows language files to default to the master U.S. English when changes are made.
// Any item not changed can be deleted, but this should only be done if performance becomes an issue.

     //General Messages.
    $pcc_lang['date_time_format'] = "d M y H:i:s";
    $pcc_lang['date_format'] = "d M y";
    $pcc_lang['forms_go'] = "Go";
    $pcc_lang['game_not_found'] = "Game number %s could not be found.";
    $pcc_lang['no_game_id'] = "No game_id present.";
    $pcc_lang['v'] = " v. ";
    $pcc_lang['black'] = "black";
    $pcc_lang['white'] = "white";
    $pcc_lang['Black'] = "Black";
    $pcc_lang['White'] = "White";
    $pcc_lang['started'] = " started ";
    $pcc_lang['error'] = "Error: ";
    $pcc_lang['Yes'] = "Yes";
    $pcc_lang['No'] = "No";
     
     //Top links and main page title.
    $pcc_lang['toplink_activegames'] = "Active Games";
    $pcc_lang['toplink_newgame'] = "New Game";
    $pcc_lang['toplink_completegames'] = "Complete Games";
    $pcc_lang['toplink_players'] = "Players";
    $pcc_lang['component_title'] = "PrinceClan Correspondence Chess Club";
     
     //Active games.
    $pcc_lang['active_game_html_title'] = "Active Chess Games";
    $pcc_lang['active_game_all'] = "All Active Games:";
    $pcc_lang['active_game_no_games'] = "There are no active games.";
    $pcc_lang['active_game_specific_challenges'] = "Challenges Issued Specifically to %s:";
    $pcc_lang['active_game_awaiting_move'] = "Games Awaiting Move by %s:";
    $pcc_lang['active_game_no_awaiting_move'] = "There are no games awaiting a move by %s.";
    $pcc_lang['active_game_opponents_move'] = "Games Awaiting Move by %s's Opponent:";
    $pcc_lang['active_game_no_opponents_move'] = "There are no games awaiting a move by %s's opponent.";
    $pcc_lang['active_game_other'] = "Other Active Games:";
    $pcc_lang['active_game_no_other'] = "There are no other active games.";
     
     //Complete games.
    $pcc_lang['complete_game_html_title'] = "Complete Chess Games";
    $pcc_lang['complete_game_all'] = "All Complete Games:";
    $pcc_lang['complete_game_no_games'] = "There are no complete games.";
    $pcc_lang['complete_game_player'] = "%s's Complete Games:";
    $pcc_lang['complete_game_no_player'] = "%s has no complete games.";
    $pcc_lang['complete_game_other'] = "Other Complete Games:";
    $pcc_lang['complete_game_no_other'] = "There are no other complete games.";
     
     //Submit move.
    $pcc_lang['submit_move_corrupt'] = "The data for the move to add is corrupted. Please try again.";
    $pcc_lang['submit_move_empty'] = 'The move is empty. Please enter a move.';
    $pcc_lang['submit_move_resign_caps_warn'] = 'You must type "RESIGN" in all caps in order to resign.';
    $pcc_lang['submit_move_draw_caps_warn'] = 'You must type "DRAW" in all caps in order to offer a draw.';
     
     //New games.
    $pcc_lang['new_game_html_title'] = "New Chess Games";
    $pcc_lang['new_game_specific'] = "Click one of the challenges specific to you to accept:";
    $pcc_lang['new_game_no_specific'] = "There are no challenges specific to you.";
    $pcc_lang['new_game_open'] = "Click one of the open challenges to accept:";
    $pcc_lang['new_game_open_not_logged_in'] = "Log in or register to accept one of the open challenges:";
    $pcc_lang['new_game_no_open'] = "There are no open challenges.";
    $pcc_lang['new_game_pending'] = "The following challenges were issued by you:";
    $pcc_lang['new_game_no_pending'] = "There are no pending challenges issued by you.";
     
     //Fork game.
    $pcc_lang['fork_game_no_player_selected'] = "You must select a player option to<br />create a new game at this position.";
     
     //Players.
    $pcc_lang['players_html_title'] = "Chess Players";
    $pcc_lang['player_html_title'] = "%s's Chess Games";
    $pcc_lang['players_not_found'] = "%s is not a recognized user id.";
    $pcc_lang['players_html_title'] = "Chess Players";
    $pcc_lang['players_html_title'] = "Chess Players";
    $pcc_lang['players_html_title'] = "Chess Players";
    
     //All games.
    $pcc_lang['all_games_html_title'] = "All Chess Games";
    $pcc_lang['all_games_pathway'] = "All Games";
    $pcc_lang['all_games_header'] = "All Games in the System";
    
     //All games.
    $pcc_lang['unknown_request'] = "Unknown Request";
     
     //pcc_EchoPlayerList()
    $pcc_lang['no_players'] = "There are no players yet.";
    $pcc_lang['player_list_title'] = "Player List and Results Summary";
    $pcc_lang['player_list_th_player'] = "Player";
    $pcc_lang['player_list_th_active'] = "Active<br />Games";
    $pcc_lang['player_list_th_complete'] = "Complete<br />Games";
    $pcc_lang['player_list_th_wins'] = "Wins";
    $pcc_lang['player_list_th_draws'] = "Draws";
    $pcc_lang['player_list_th_active_white'] = "Active<br />Games<br />White";
    $pcc_lang['player_list_th_complete_white'] = "Complete<br />Games<br />White";
    $pcc_lang['player_list_th_wins_white'] = "Wins<br />White";
    $pcc_lang['player_list_th_draws_white'] = "Draws<br />White";
    $pcc_lang['player_list_th_active_black'] = "Active<br />Games<br />Black";
    $pcc_lang['player_list_th_complete_black'] = "Complete<br />Games<br />Black";
    $pcc_lang['player_list_th_wins_black'] = "Wins<br />Black";
    $pcc_lang['player_list_th_draws_black'] = "Draws<br />Black";
     
     //pcc_EchoNewGameForm()
    $pcc_lang['new_game_form_heading'] = "Enter info to issue a challenge:";
    $pcc_lang['new_game_form_color'] = "Color:";
    $pcc_lang['new_game_form_white'] = "White";
    $pcc_lang['new_game_form_black'] = "Black";
    $pcc_lang['new_game_form_opponent'] = "Opponent:";
    $pcc_lang['new_game_form_any_player'] = "** Any Player **";
    $pcc_lang['new_game_form_notification'] = "Notification:";
    $pcc_lang['new_game_form_notification_yes'] = "Notify me via email when my opponent moves.";
    $pcc_lang['new_game_form_notification_no'] = "Do not notify me via email when my opponent moves - I will check daily.";
    $pcc_lang['new_game_form_comment_head'] = "Comments:";
     
     //pcc_EchoForkGameForm()
    $pcc_lang['fork_game_first_option'] = "--Create new game at this position--";
    $pcc_lang['fork_game_same_players'] = "Use same players";
    $pcc_lang['fork_game_switch_sides'] = "Same players, switch sides";
    $pcc_lang['fork_game_open_white'] = "Post open challenge with me as white";
    $pcc_lang['fork_game_open_black'] = "Post open challenge with me as black";
    
     //pcc_ProcessForkGame()
    $pcc_lang['process_fork_no_login'] = "You must be logged in correctly to create a new game.";
    $pcc_lang['process_fork_no_color'] = "A correct color was not selected.";
    $pcc_lang['process_fork_bad_fork'] = "The fork value %s is incorrect.";
    $pcc_lang['process_fork_comment'] = "This game was forked at move %1\$s/%2\$s from the game between %3\$s v. %4\$s that was started on %5\$s.";
    $pcc_lang['process_fork_last_move'] = "Last move transferred from parent game.";
     
     //pcc_EchoAcceptGameForm()
    $pcc_lang['accept_game_header'] = "Accept Offer to Play %1\$s v. %2\$s";
    $pcc_lang['accept_game_notify'] = "Notify me via email when my opponent moves.";
    $pcc_lang['accept_game_no_notify'] = "Do not notify me via email when my opponent moves - I will check daily.";
    $pcc_lang['accept_game_accept'] = "Accept Challenge";
    $pcc_lang['accept_game_decline'] = "Decline Challenge";
    $pcc_lang['accept_game_no_login'] = "You must be logged in to accept a challenge for a new game.";
    
     //pcc_EchoRevokeChallengeForm()
    $pcc_lang['revoke_game_header'] = "Your Challenge for the Game %s v. %s";
    $pcc_lang['revoke_game_warn'] = "WARNING: Once you click &quot;Revoke Challenge&quot; this game will be deleted with no prompting.";
    $pcc_lang['revoke_game_revoke'] = "Revoke Challenge";
    $pcc_lang['revoke_game_no_login'] = "You must be logged in to revoke a challenge for a new game.";
     
     //pcc_ProcessDeclineGame()
    $pcc_lang['decline_already_begun'] = "This game has already begun an may not be declined.";
    $pcc_lang['decline_not_specific'] = "This challenge was not specific to you so you may not decline it.";
    $pcc_lang['decline_subject'] = "Prince Clan Chess: Your challenge to %s has been declined.";
    $pcc_lang['decline_body'] = "%1\$s declined to accept your challenge to play %2\$s.";
    $pcc_lang['decline_message_notify'] = "%1\$s has been notified by email of your declining to play %2\$s.";
    $pcc_lang['decline_message_no_notify'] = "%1\$s has not been notified by email of your declining to play %2\$s.";
    $pcc_lang['decline_no_login'] = "You must be logged in to decline a game.";
     
     //pcc_RevokeChallenge()
    $pcc_lang['revoke_already_begun'] = "This game has already begun an may not be revoked.";
    $pcc_lang['revoke_not_specific'] = "This challenge was not specific to you so you may not revoke it.";
    $pcc_lang['revoke_success'] = "The challenge issued for %s has been revoked.";
    $pcc_lang['revoke_no_login'] = "You must be logged in to revoke a challenge.";
    
     //pcc_ProcessAcceptGame()
    $pcc_lang['accept_no_login'] = "You must be logged in to accept a challenge.";
    $pcc_lang['accept_already'] = "This game was already accepted by someone else: ";
    $pcc_lang['accept_subject'] = "Prince Clan Chess: Your challenge has been accepted.";
    $pcc_lang['accept_body'] = "%1\$s agreed to play %2\$s at %3\$s.";
    $pcc_lang['accept_you_will_be_notified'] = "You will be notified by email when your opponent moves.";
    $pcc_lang['accept_you_will_not_be_notified'] = "You will not be notified by email when<br />your opponent moves. Please check back daily.";
    $pcc_lang['accept_unknown'] = "Unknown situation in pcc_ProcessAcceptGame().";
    $pcc_lang['accept_opponent_notified'] = "%1\$s has been notified by email of your agreement to play %2\$s.";
    $pcc_lang['accept_opponent_not_notified'] = "%1\$s has not been notified by email of your agreement to play %2\$s.";
     
     //pcc_ProcessNewGame()
    $pcc_lang['issue_challenge_no_login'] = "You must be logged in correctly to issue a challenge.";
    $pcc_lang['issue_challenge_no_color'] = "A correct color was not selected.";
    $pcc_lang['issue_you_will_be_notified'] = "You will be notified via email when this challenge is accepted.";
    $pcc_lang['issue_you_will_not_be_notified'] = "You will not be notified via email when this challenge is accepted. Please check back daily.";
    $pcc_lang['issue_message'] = "Your request for an opponent to play %s has been saved.";
    $pcc_lang['issue_no_login'] = "You must be logged in to create a new game.";
    
     //pcc_ShowAddMoveForm()
    $pcc_lang['add_form_move'] = "Move:";
    $pcc_lang['add_form_help'] = "Help";
    $pcc_lang['add_form_instructions'] = "Type RESIGN in Move to resign, DRAW to offer draw.";
    $pcc_lang['add_form_comment'] = "Comment:";
    $pcc_lang['add_form_notify'] = "Notify me when my opponent moves.";
    
     //Game List
    $pcc_lang['game_list_players'] = "Players";
    $pcc_lang['game_list_status'] = "Status";
    $pcc_lang['game_list_started'] = "Started";
    $pcc_lang['game_list_num_moves'] = "#&nbsp;Moves";
    $pcc_lang['game_list_last_move'] = "Last&nbsp;Move";
    $pcc_lang['game_list_comments'] = "Comments";
     
     //pcc_DrawGame()
    $pcc_lang['draw_no_login'] = "You must be logged in to offer a draw.";
    $pcc_lang['draw_wrong_player'] = "This game is between %1\$s and %2\$s. Only these players may offer draws in this game.";
    $pcc_lang['draw_message_notify'] = ' An email was sent to notify<br />your opponent of your draw offer.';
    $pcc_lang['draw_message_no_notify'] = ' Your opponent has not been<br />notified of your draw offer.';
    
     //pcc_ResignGame()
    $pcc_lang['resign_no_login'] = "You must be logged in to resign.";
    $pcc_lang['resign_wrong_player'] = "This game is between %1\$s and %2\$s. Only these players may resign in this game.";
    $pcc_lang['resign_message_notify'] = ' An email was sent to notify<br />your opponent of your resignation.';
    $pcc_lang['resign_message_no_notify'] = ' Your opponent has not been<br />notified of your resignation.';
    
     //pcc_ProcessAcceptDraw()
    $pcc_lang['accept_draw_no_login'] = "You must be logged in to accept or reject a draw.";
    $pcc_lang['accept_draw_wrong_player'] = "This game is between %1\$s and %2\$s. Only these players may accept or reject draws in this game.";
    $pcc_lang['accept_draw_accept_notify'] = ' An email was sent to notify<br />your opponent that you accept the draw.';
    $pcc_lang['accept_draw_accept_no_notify'] = ' Your opponent has not been<br />notified that you accept the draw.';
    $pcc_lang['accept_draw_reject_notify'] = ' An email was sent to notify<br />your opponent that you reject the draw.';
    $pcc_lang['accept_draw_reject_no_notify'] = ' Your opponent has not been<br />notified that you reject the draw.';
    
     //pcc_AwaitingChallengerName()
    $pcc_lang['awaiting_player'] = "&lt;Awaiting Player&gt;";
    
     //pcc_GetGameStatus()
    $pcc_lang['game_status_awaiting_white'] = "Awaiting white";
    $pcc_lang['game_status_awaiting_black'] = "Awaiting black";
    $pcc_lang['game_status_admin_suspend'] = "Admin suspend";
    $pcc_lang['game_status_white_draw_offer'] = "White offered draw";
    $pcc_lang['game_status_black_draw_offer'] = "Black offered draw";
    $pcc_lang['game_status_white_to_move'] = "White to move";
    $pcc_lang['game_status_black_to_move'] = "Black to move";
    $pcc_lang['game_status_white_mated_black'] = "White mated black";
    $pcc_lang['game_status_black_mated_white'] = "Black mated white";
    $pcc_lang['game_status_stalemate'] = "Stalemate";
    $pcc_lang['game_status_draw_agreed_to'] = "Draw agreed to";
    $pcc_lang['game_status_white_resigned'] = "White resigned";
    $pcc_lang['game_status_black_resigned'] = "Black resigned";
    $pcc_lang['game_status_unknown_result'] = "Unknown result";
     
     //pcc_EchoGame()
    $pcc_lang['echo_game_start_position'] = 'The game will start in the following position:';
    $pcc_lang['echo_game_player_offered_draw'] = "You offered your opponent a draw.<br />You must wait for a response.";
    $pcc_lang['echo_game_white_offered_draw'] = "White has offered a draw.<br />Black has not responded.";
    $pcc_lang['echo_game_black_offered_draw'] = "You offered your opponent a draw.<br />You must wait for a response.";
    $pcc_lang['echo_game_export'] = "export game";
    $pcc_lang['echo_game_refresh'] = "Refresh";
    $pcc_lang['echo_game_not_started'] = "Game not started, ";
    $pcc_lang['echo_game_over'] = "Game over, ";
    $pcc_lang['echo_game_last_position_to_move'] = "Go to the last position to enter your move.";
    $pcc_lang['echo_game_opponents_move'] = "It's your opponent's move.";
     
     //pcc_ShowAcceptDrawForm()
    $pcc_lang['accept_draw_prompt'] = 'Accept the draw?';
    
     //pcc_ProcessMove()
    $pcc_lang['process_move_no_move'] = "You must enter a move.";
    $pcc_lang['process_move_no_login'] = "You must be logged in to enter a move.";
    $pcc_lang['process_move_wrong_player'] = "This game is between %1\$s and %2\$s. Only these players may enter a move in this game.";
    $pcc_lang['process_move_accept_no_notify'] = ' Your opponent has not been<br />notified of your move.';
    $pcc_lang['process_move_reject_notify'] = ' An email was sent to notify<br />your opponent of your move.';
    $pcc_lang['process_move_checkmate'] = 'The move %s resulted in checkmate. You win!';
    $pcc_lang['process_move_stalemate'] = 'The move %s resulted in stalemate. The game is a draw.';
    $pcc_lang['process_move_added'] = 'The move %s was added to the game.';
    $pcc_lang['process_move_invalid'] = 'The move %s is not valid from this position.';
    $pcc_lang['process_move_error'] = 'There was an error reading your game from the database.';
     
     //pcc_SendMoveEmail()
    $pcc_lang['send_mail_subject'] = "Prince Clan Chess Automated Move Notification";
    $pcc_lang['send_mail_comment'] = " %s made the following comment: ";
    $pcc_lang['send_mail_resign'] = "%1\$s resigned in the game %2\$s%3\$s%4\$s at %5\$s.";
    $pcc_lang['send_mail_draw_offer'] = "%1\$s offered a draw in the game %2\$s%3\$s%4\$s at %5\$s.";
    $pcc_lang['send_mail_draw_accept'] = "%1\$s accepted a draw in the game %2\$s%3\$s%4\$s at %5\$s.";
    $pcc_lang['send_mail_draw_reject'] = "%1\$s rejected a draw in the game %2\$s%3\$s%4\$s at %5\$s.";
    $pcc_lang['send_mail_move'] = "%1\$s made the move %2\$s in the game %3\$s%4\$s%5\$s at %6\$s.";
     
     //pcc_GetDiscussThisLink()
    $pcc_lang['discuss_this_link_view_comments'] = 'View comments about this game in the Chess forum.';
    $pcc_lang['discuss_this_link_this_game'] = 'Discuss this game in the Chess forum.';
    $pcc_lang['discuss_this_link_games'] = 'Discuss games in the Chess forum.';
     
     //Module
    $pcc_lang['pcc_status_your_turn_header'] = 'Chess Games - Your Turn';
    $pcc_lang['pcc_status_your_turn_none'] = 'There are no chess games in which it is your turn.';
    $pcc_lang['pcc_status_opp_turn_header'] = "Chess Games - Opponent's Turn";
    $pcc_lang['pcc_status_opp_turn_none'] = "There are no chess games in which it is your opponent's turn.";
    $pcc_lang['pcc_status_spec_challenges'] = "Chess Challenges Specific to You";
    $pcc_lang['pcc_status_spec_challenges_none'] = "There are no chess challenges specific to you.";
    $pcc_lang['pcc_status_open_challenges'] = "Open Chess Challenges";
    $pcc_lang['pcc_status_open_challenges_none'] = "There are no open chess challenges.";

    $pcc_lang['add_form_help_text'] = "'Enter moves using the notation start-end using algebraic notation for square positions. For example, e2-e4.\\n\\n' +
		 'Clicking on the start and end square will put the correct notation in the move box.\\n\\n' +
		 'To castle, enter the start square and the target square for the King. For example, e1-g1 or e1-c1. All castling rules are enforced.\\n\\n' +
		 'To capture a pawn en passant, enter the square of the pawn being moved and the square the pawn will end up in. For example, e4-f3.\\n\\n' +
		 'Pawns are automatically promoted to queens unless specified. For example, e7-e8 N will promote the pawn to a Knight. Use Q, B, R, N. ' +
		 'The space between the target square and piece designation is mandatory.\\n\\n' +
		 'Type DRAW to offer or accept a draw. There is no way to withdraw a draw offer once made.\\n\\n'+
		 'Type RESIGN to resign. There is no way to withdraw a resignation.'";

	//This array contains the letter to use in algebraic notation for each piece.
	//Do not change the number of elements in this array or the order.
	$pcc_lang_pgn_replace = array(
		"K",  //King
		"Q",  //Queen
		"R",  //Rook
		"B",  //Bishop
		"N"); //Knight
 ?>