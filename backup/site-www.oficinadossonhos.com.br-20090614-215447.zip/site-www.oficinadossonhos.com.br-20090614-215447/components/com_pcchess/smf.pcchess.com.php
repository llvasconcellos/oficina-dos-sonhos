<?php
function pcc_DiscussGeneralLink() {
	//Change this to a link to discuss or simply return an empty string to have no discussions.
	return "http://www.princeclan.org/component/option,com_smf/Itemid,83/board,3.0";
}

function pcc_GetLinkFromGameInfo() {
	return '';
}	
?>