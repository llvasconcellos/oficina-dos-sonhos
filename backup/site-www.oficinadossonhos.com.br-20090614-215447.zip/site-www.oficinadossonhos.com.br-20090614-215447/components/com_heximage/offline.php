<?php
/**
* HeXimage - A Mambo/Joomla! photogallery Component
* @version 2.1.2
* @package HeXimage
* @copyright (C) 2006 by A.J.W.P. Ruitenberg
* @license Released under the terms of the GNU General Public License
**/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

?>
<center>
  <img src="<?php echo $mosConfig_live_site; ?>/components/com_heximage/images/logo.gif">
  <br /><br />
  <h3><?php echo "$HeXimage_offline_message"; ?></h3>
  <br /><br />
  <span class='small'>Powered by <a href='http://www.hexa-design.com/' target='_blank'>HeXimage <?php echo "$heximageversion"; ?></a></span>
</center>