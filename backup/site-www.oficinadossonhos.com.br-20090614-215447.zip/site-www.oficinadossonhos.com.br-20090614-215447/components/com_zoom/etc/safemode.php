<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
$ftp_server = "ftp.foo.com";
$ftp_username = "anonymous";
$ftp_pass = "foo@foo.com";
$ftp_hostdir = "/home/some_user";
?>